# PhD Thesis LaTeX template 
## Department of Hydrology and hydraulic engineering, Vrije Universiteit Brussel


## General tips

### Long compilation time
To avoid a long compilation time, you can first to a 'fast compile', which is a compile without the figures. 

If you have figures of a large data format (e.g. .png, .jpeg etc), converting them to .pdf might speed up compilation times. 

### Book cover
It is the easiest to create your cover in powerpoint. If you print you thesis at the crazy copy center, they provide ppt templates in the right format (e.g. 16 by 24 cm or 17 by 24 cm)
 
## Something to add? 
Feel free to include it in the template or here! 